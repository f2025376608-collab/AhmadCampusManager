#include "filehandler.h"

vector<vector<string>> readTXT(string filename)
{
    vector<vector<string>> data;

    return data;
}

void writeTXT(string filename, vector<vector<string>>& data)
{

}

void appendTXT(string filename, vector<string> row)
{

}

vector<string> findRow(vector<vector<string>>& data, int col, string value)
{
    vector<string> empty;
    return empty;
}

bool rowExists(vector<vector<string>>& data, int col, string value)
{
    return false;
}
