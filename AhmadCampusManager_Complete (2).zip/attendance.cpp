#include <iostream>
#include <fstream>
#include <string>
#include "attendance.h"
using namespace std;
void attendanceMenu(){
 string roll,status; 
 cout<<"Enter Roll No: "; cin>>roll;
 cout<<"Present/Absent: "; cin>>status;
 ofstream file("attendance_log.txt", ios::app);
 file<<roll<<","<<status<<endl;
 cout<<"Attendance saved!\n";
}
