#ifndef ATTENDANCE_H
#define ATTENDANCE_H
void attendanceMenu();
#endif
