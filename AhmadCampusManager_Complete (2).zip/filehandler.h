#ifndef FILEHANDLER_H
#define FILEHANDLER_H

#include <iostream>
#include <fstream>
#include <vector>
#include <string>

using namespace std;

vector<vector<string>> readTXT(string filename);
void writeTXT(string filename, vector<vector<string>>& data);
void appendTXT(string filename, vector<string> row);
vector<string> findRow(vector<vector<string>>& data, int col, string value);
bool rowExists(vector<vector<string>>& data, int col, string value);

#endif
