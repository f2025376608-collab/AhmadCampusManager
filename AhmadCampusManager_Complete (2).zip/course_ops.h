#ifndef COURSE_OPS_H
#define COURSE_OPS_H

void courseMenu();

#endif
