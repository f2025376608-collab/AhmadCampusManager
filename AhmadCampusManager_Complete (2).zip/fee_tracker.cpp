#include <iostream>
#include <fstream>
#include <string>
#include "fee_tracker.h"
using namespace std;
void feeMenu(){
 string roll,status;
 cout<<"Enter Roll No: "; cin>>roll;
 cout<<"Fee Status (Paid/Unpaid): "; cin>>status;
 ofstream file("fees.txt", ios::app);
 file<<roll<<","<<status<<endl;
 cout<<"Fee record saved!\n";
}
