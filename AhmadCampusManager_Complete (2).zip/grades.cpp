#include <iostream>
#include <fstream>
#include <string>
#include "grades.h"
using namespace std;
void gradesMenu(){
 string roll,grade;
 cout<<"Enter Roll No: "; cin>>roll;
 cout<<"Enter Grade: "; cin>>grade;
 ofstream file("grades.txt", ios::app);
 file<<roll<<","<<grade<<endl;
 cout<<"Grade added!\n";
}
