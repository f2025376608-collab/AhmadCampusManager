#include <iostream>
#include "student_ops.h"
#include "course_ops.h"
#include "attendance.h"
#include "grades.h"
#include "fee_tracker.h"
#include "reports.h"
using namespace std;
int main(){
 int choice;
 do{
  cout<<"
===== CAMPUS MANAGER =====
";
  cout<<"1. Students
2. Courses
3. Attendance
4. Grades
5. Fee Tracker
6. Reports
0. Exit
Choice: ";
  cin>>choice;
  switch(choice){
   case 1: studentMenu(); break;
   case 2: courseMenu(); break;
   case 3: attendanceMenu(); break;
   case 4: gradesMenu(); break;
   case 5: feeMenu(); break;
   case 6: reportsMenu(); break;
   case 0: cout<<"Goodbye!
"; break;
   default: cout<<"Invalid choice
";
  }
 }while(choice!=0);
 return 0;
}
