#include <iostream>
#include "course_ops.h"

using namespace std;

void courseMenu()
{
    int choice;

    do
    {
        cout << "\n===== COURSE MANAGEMENT =====\n";
        cout << "1. Add Course\n";
        cout << "2. Enroll Student\n";
        cout << "3. View Courses\n";
        cout << "4. Drop Course\n";
        cout << "0. Back to Main Menu\n";
        cout << "Enter Choice: ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                cout << "\nAdd Course Selected.\n";
                break;

            case 2:
                cout << "\nEnroll Student Selected.\n";
                break;

            case 3:
                cout << "\nView Courses Selected.\n";
                break;

            case 4:
                cout << "\nDrop Course Selected.\n";
                break;

            case 0:
                cout << "\nReturning to Main Menu...\n";
                break;

            default:
                cout << "\nInvalid Choice!\n";
        }

    } while(choice != 0);
}
