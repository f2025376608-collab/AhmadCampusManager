#include <iostream>
#include <fstream>
#include <string>
#include "reports.h"
using namespace std;
void reportsMenu(){
 ifstream file("students.txt");
 string line;
 cout<<"\n===== STUDENT REPORT =====\n";
 while(getline(file,line)) cout<<line<<endl;
}
