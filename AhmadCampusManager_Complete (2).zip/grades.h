#ifndef GRADES_H
#define GRADES_H
void gradesMenu();
#endif
