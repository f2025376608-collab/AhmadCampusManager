#include <iostream>
#include <fstream>
#include <string>
#include "student_ops.h"
using namespace std;

void addStudent(){
    string roll,name,dept,semester,cgpa,status;
    cout << "Enter Roll No: "; cin >> roll;
    cin.ignore();
    cout << "Enter Name: "; getline(cin,name);
    cout << "Enter Department: "; getline(cin,dept);
    cout << "Enter Semester: "; getline(cin,semester);
    cout << "Enter CGPA: "; getline(cin,cgpa);
    cout << "Enter Status: "; getline(cin,status);

    ofstream file("students.txt", ios::app);
    file << roll << "," << name << "," << dept << "," << semester << "," << cgpa << "," << status << endl;
    file.close();
    cout << "Student Added Successfully!\n";
}

void studentMenu(){
    int choice;
    do{
        cout << "\n===== STUDENT MANAGEMENT =====\n";
        cout << "1. Add Student\n";
        cout << "2. View Students\n";
        cout << "0. Back\n";
        cin >> choice;

        switch(choice){
            case 1: addStudent(); break;
            case 2: cout << "View Students Selected\n"; break;
            case 0: break;
            default: cout << "Invalid Choice\n";
        }
    }while(choice != 0);
}
